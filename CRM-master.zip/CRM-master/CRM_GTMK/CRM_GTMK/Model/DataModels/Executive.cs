﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRM_GTMK.Model.DataModels
{
	public class Executive
	{
		public int assignedWordsCount { get; set; }
		public int progress { get; set; }
		public string id { get; set; }
		public string type { get; set; }
	}
}
